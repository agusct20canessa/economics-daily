
import React from 'react'

export default function Header(){
  return (
    <header className="bg-white shadow">
      <div className="max-w-6xl mx-auto px-4 py-5 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-primary rounded flex items-center justify-center text-white font-bold">ED</div>
          <div>
            <div className="text-2xl header-logo">Economics Daily</div>
            <div className="text-sm text-gray-500">Economía Internacional · Política Internacional</div>
          </div>
        </div>

        <nav className="hidden md:flex items-center space-x-6 text-sm">
          <a className="hover:underline" href="#">Economía</a>
          <a className="hover:underline" href="#">Política</a>
          <a className="hover:underline" href="#">Análisis</a>
          <a className="hover:underline" href="#">Último Momento</a>
        </nav>

        <div className="hidden md:block">
          <input placeholder="Buscar..." className="border rounded px-3 py-2 text-sm outline-none" />
        </div>
      </div>
    </header>
  )
}
