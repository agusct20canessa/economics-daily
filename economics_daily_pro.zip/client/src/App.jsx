
import React, {useEffect, useState} from 'react'
import Header from './components/Header.jsx'
import ArticleCard from './components/ArticleCard.jsx'

export default function App(){
  const [articles, setArticles] = useState([])
  useEffect(()=>{
    fetch('/api/articles').then(r=>r.json()).then(setArticles).catch(()=>{
      // fallback: load embedded minimal set
      setArticles(window.__EMBEDDED_ARTICLES || [])
    })
  },[])

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <Header />
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white p-6 rounded-2xl shadow">
              <h2 className="text-xl font-bold mb-2">Últimas</h2>
              <p className="text-sm text-gray-500">Actualizaciones en Economía y Política Internacional</p>
            </div>
            <div className="grid gap-6 md:grid-cols-2">
              {articles.slice(0,12).map((a,i)=>(<ArticleCard key={i} article={a} />))}
            </div>
            <div className="text-center">
              <button className="px-4 py-2 rounded border">Cargar más</button>
            </div>
          </div>

          <aside className="space-y-6">
            <div className="bg-white p-4 rounded-2xl shadow">
              <h3 className="font-semibold mb-2">Último Momento</h3>
              <ul className="text-sm text-gray-600 space-y-2">
                {articles.slice(0,6).map((a,i)=>(<li key={i}><a href="#" className="hover:underline">{a.title}</a></li>))}
              </ul>
            </div>

            <div className="bg-white p-4 rounded-2xl shadow">
              <h4 className="font-semibold mb-2">Publicidad</h4>
              <div className="h-36 bg-gray-100 rounded flex items-center justify-center text-gray-400">Espacio AdSense</div>
            </div>

            <div className="bg-white p-4 rounded-2xl shadow">
              <h4 className="font-semibold mb-2">Análisis</h4>
              <p className="text-sm text-gray-600">Artículos largos y profundos seleccionados por la redacción automática.</p>
            </div>
          </aside>
        </section>
      </main>

      <footer className="bg-white border-t mt-8">
        <div className="max-w-6xl mx-auto px-4 py-6 text-sm text-gray-500">
          © {new Date().getFullYear()} Economics Daily — Economía Internacional & Política Internacional · Política de privacidad incluida.
        </div>
      </footer>
    </div>
  )
}
