
Economics Daily — Proyecto Profesional (ZIP)
===========================================

Contenido:
- client/  -> Frontend (Vite + React + Tailwind)
- server/  -> Backend (Express) con RSS fetcher y /api/articles
- data/articles.json -> 300 artículos automatizados
- vercel.json -> configuración para desplegar en Vercel
- privacy-policy.html -> placeholder (necesario para AdSense)

Instrucciones rápidas para publicar en Vercel:
1) Subí este ZIP a un repo en GitHub (o subilo directamente en Vercel)
2) En Vercel: nuevo proyecto -> importar repo
   - Asegurate de que la carpeta 'client' se buildée (Vercel detecta)
3) En Variables de entorno (opcional): RSS_FEEDS (lista de RSS separadas por comas)
4) Deploy -> listo. Tu backend estará disponible en /api/articles
5) Agrega AdSense: pega tu código de cliente en client/index.html (head) y coloca bloques <ins> en client/src/components/ArticleCard.jsx

Notas importantes:
- Antes de monetizar revisá las políticas de Google AdSense y reemplaza la política de privacidad con una real.
- Si querés que yo haga el deploy directo en Vercel, decime y lo hago (necesito que me autorices a usar tu cuenta o que me des acceso al repo).
