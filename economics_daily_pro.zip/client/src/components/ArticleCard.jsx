
import React from 'react'

export default function ArticleCard({article}){
  return (
    <article className="bg-white p-4 rounded-2xl shadow article-card">
      <div className="text-xs text-gray-400 mb-2">{article.category} · {new Date(article.datetime).toLocaleString()}</div>
      <h3 className="font-semibold text-lg mb-2">{article.title}</h3>
      <p className="text-sm text-gray-600 mb-3">{article.summary}</p>
      <div className="flex items-center justify-between text-xs text-gray-400">
        <div>Fuente: {article.source || 'Economics Daily'}</div>
        <button className="px-3 py-1 rounded border text-sm">Leer</button>
      </div>
    </article>
  )
}
